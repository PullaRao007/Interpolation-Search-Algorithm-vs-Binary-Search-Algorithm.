#!/usr/bin/env python
# coding: utf-8

# In[4]:


import random
from threading import Thread
import psutil
import threading
import math
import time
import pandas
from matplotlib import pyplot as plt
import numpy as np

def __init__(self, arr):
	self.arr = arr
        
def interpolationSearch(arr, lo, hi, x):
	# Since array is sorted, an element present
	# in array must be in range defined by corner
	if (lo <= hi and x >= arr[lo] and x <= arr[hi]):
		pos = lo + ((hi - lo) // (arr[hi] - arr[lo]) *
					(x - arr[lo]))
		# Condition of target found
		if arr[pos] == x:
			return pos
		# If x is larger, x is in right subarray
		if arr[pos] < x:
			return interpolationSearch(arr, pos + 1,
									hi, x)
		# If x is smaller, x is in left subarray
		if arr[pos] > x:
			return interpolationSearch(arr, lo,
									pos - 1, x)
	return -1

def interpolationOutput():
	# Array of items in which
	# search will be conducted
	arr = [10, 12, 13, 16, 18, 19, 20,
	21, 22, 23, 24, 33, 35, 42, 47, 29,
	50, 110,769, 678, 4561, 455, 231, 567,
	767, 900, 344, 517, 689, 456, 7718, 998]
	n = len(arr)
	# Element to be searched
	x = 18
	index = interpolationSearch(arr, 0, n - 1, x)
	if index != -1:      
		list1 = [psutil.cpu_percent(), 
					psutil.virtual_memory().percent,
					psutil.disk_usage('/').percent,
					psutil.Process().memory_info().rss,
					psutil.Process().memory_info().vms,
					psutil.Process().memory_info().num_page_faults]
		return list1
	else:
		print("Element not found")
		return -1

def binarySearch(arr, l, r, x):
	# Check base case
	if r >= l:
		mid = l + (r - l) // 2
		# If element is present at the middle itself
		if arr[mid] == x:
			return mid
		# If element is smaller than mid, then it
		# can only be present in left subarray
		elif arr[mid] > x:
			return binarySearch(arr, l, mid-1, x)
		# Else the element can only be present
		# in right subarray
		else:
			return binarySearch(arr, mid + 1, r, x)
	else:
		# Element is not present in the array
		return -1

def binarySearchOutput():
	# Array of items
	arr = [2, 3, 4, 10, 40, 66, 89, 91, 98, 103,
			108, 111, 123, 156, 178, 234, 256, 276,
			343, 567, 678, 721, 746, 765, 801, 834]
	x = 10
	# Function call
	result = binarySearch(arr, 0, len(arr)-1, x)
	if result != -1:
		list2 = [psutil.cpu_percent(),
					psutil.virtual_memory().percent,
					psutil.disk_usage('/').percent,
					psutil.Process().memory_info().rss,
					psutil.Process().memory_info().vms,
					psutil.Process().memory_info().num_page_faults]
		return list2
	else:
		print("Element is not present in array")
		return -1
        
def run():
	t1 = threading.Thread(target=interpolationOutput)
	t2 = threading.Thread(target=binarySearchOutput)
	t1.start()
	t2.start()
	list3 = [psutil.cpu_percent(),
				psutil.virtual_memory().percent,
				psutil.disk_usage('/').percent,+
				psutil.Process().memory_info().rss,
				psutil.Process().memory_info().vms,
				psutil.Process().memory_info().num_page_faults]
	t1.join()
	t2.join()
	return list3

if __name__ == '__main__':
	start_time = time.time()
	base_list = [psutil.cpu_percent(),
					psutil.virtual_memory().percent,
					psutil.disk_usage('/').percent,
					psutil.Process().memory_info().rss,
					psutil.Process().memory_info().vms,
					psutil.Process().memory_info().num_page_faults]
	data3 = run()
    
	left_label_first = ["Actual", "-Base", "Relative"]
	top_label_second = ["CPU%", "Memory%", "Disk%", "rss", "vms", "pagefaults"]
    
	#for interpolation search:
	print("----------------interpolation search sort table -----------------------------")
	data1 = interpolationOutput()
	interpolation_relative = list()
	for i in range(len(data1)):
		ele = data1[i]-base_list[i]
		interpolation_relative.append(ele)
        
	interpolation_table_data = np.array([data1, base_list, interpolation_relative])
	print(pandas.DataFrame(interpolation_table_data, left_label_first, top_label_second))
    
	colors = ['red', 'blue', 'violet']
	pi1_data = np.array([data1[:3]])
    
	labels = ['CPU Usage', 'Memory Usage', 'Hard Disk Usage']
	explode = [0, 0, 0]
    
	plt.pie(data1[:3], labels=labels, explode=explode, colors=colors, shadow=True,
                 wedgeprops={'edgecolor': 'black'})
        
	plt.axis('equal')
	plt.title("Statistics of Interpolation Search")
	plt.show()
	print("Program executed in about %s seconds" % (time.time() - start_time))
	print("\n")
    
	#for binary search:
	print("------------binary search table --------------------------")
	data2 = binarySearchOutput()
	binary_relative = list()
	for i in range(len(data2)):
		ele = data2[i] - base_list[i]
		binary_relative.append(ele)
        
	binary_table_data = np.array([data2, base_list, binary_relative])
	print(pandas.DataFrame(binary_table_data, left_label_first, top_label_second))
    
	colors = ['red', 'blue', 'violet']
	pi2_data = np.array([data2[:3]])
    
	labels = ['CPU Usage', 'Memory Usage', 'Hard Disk Usage']
	explode = [0, 0, 0]
	plt.pie(data2[:3], labels=labels, explode=explode, colors=colors, shadow=True,
                 wedgeprops={'edgecolor': 'black'})
	plt.axis('equal')
	plt.title("Statistics of Binary Search")
	plt.show()
	print("Program executed in about %s seconds" % (time.time() - start_time))
	print("\n")
    
	#for interpolation-binary-search:
	print("------------interpolation-binary search table --------------------------")
	both_relative = list()
	for i in range(len(data3)):
		ele = data3[i] - base_list[i]
		both_relative.append(ele)
        
	both_table_data = np.array([data3, base_list, both_relative])
	print(pandas.DataFrame(both_table_data, left_label_first, top_label_second))
    
	colors = ['red', 'blue', 'violet']
	pi3_data = np.array([data3[:3]])
        
	labels = ['CPU Usage', 'Memory Usage', 'Hard Disk Usage']
	explode = [0, 0, 0]
	plt.pie(data3[:3], labels=labels, explode=explode, colors=colors, shadow=True,
                 wedgeprops={'edgecolor': 'black'})
	plt.axis('equal')
	plt.title("Statistics of interpolation search and binary search while running in Parallel")
	plt.show()
	print("interpolation search and binary search programs are executed in about %s seconds" % (time.time() - start_time))
    
	cpu_data = [data1[0], data2[0], data3[0]]
	memory_data = [data1[1], data2[1], data3[1]]
	disk_data = [data1[2], data2[2], data3[2]]
	rss_data = [data1[3], data2[3], data3[3]]
	vms_data = [data1[4], data2[4], data3[4]]
	pagefaults_data = [data1[5], data2[5], data3[5]]
	mylabels = ["Interpolation Search","Binary Search","Interpolation & Binary Search"]
    
	pie1_data = np.array(cpu_data)
	pie2_data = np.array(memory_data)
	pie3_data = np.array(disk_data)
	pie4_data = np.array(rss_data)
	pie5_data = np.array(vms_data)
	pie6_data = np.array(pagefaults_data)
    
	fig, ax = plt.subplots(2,3)
    
	ax[0,0].pie(pie1_data, labels = cpu_data, labeldistance=0.5)
	ax[0,1].pie(pie2_data, labels = memory_data, labeldistance=0.5)
	ax[0,2].pie(pie3_data, labels = disk_data, labeldistance=0.5)
	ax[1,0].pie(pie4_data, labels = rss_data, labeldistance=0.5)
	ax[1,1].pie(pie5_data, labels = vms_data, labeldistance=0.5)
	ax[1,2].pie(pie6_data, labels = pagefaults_data, labeldistance=0.5)
    
	ax[0,0].set_title("CPU_Usage")
	ax[0,1].set_title("Memory_Usage")
	ax[0,2].set_title("Disk_Usage")
	ax[1,0].set_title("RSS")
	ax[1,1].set_title("VMS")
	ax[1,2].set_title("pagefaults")
    
	colors = ['red', 'yellow', 'lightblue']
	explode = [0, 0, 0]
	ax[0,2].pie(disk_data, labels=mylabels, explode=explode, colors=colors, shadow=True,
                 wedgeprops={'edgecolor': 'black'})
	plt.axis('equal')
	ax[0,2].set_title("Disk_Usage")
	plt.show()
    
	colors = ['red', 'yellow', 'lightblue']
	pie3_data = np.array([data3[:3]])
       
       
	labels = ['CPU Usage', 'Memory Usage', 'Hard Disk Usage']
	explode = [0, 0, 0]
	plt.pie(data3[:3], labels=labels, explode=explode, colors=colors, shadow=True,
                wedgeprops={'edgecolor': 'black'})
	plt.axis('equal')
	plt.title("Statistics of interpolation search and binary search while running in Parallel")
	plt.show()
	print("Interpolation Search and Binary Search programs are executed in about %s seconds" % (time.time() - start_time))

	colors = ['red', 'blue', 'violet']
	pie2_data = np.array([data2[:3]])
        
	labels = ['CPU Usage', 'Memory Usage', 'Hard Disk Usage']
	explode = [0, 0, 0]
	plt.pie(data2[:3], labels=labels, explode=explode, colors=colors, shadow=True,
                 wedgeprops={'edgecolor': 'black'})
	plt.axis('equal')
	plt.title("Statistics of Binary Search")
	plt.show()
	print("Program executed in about %s seconds" % (time.time() - start_time))
	print("\n")
    
    
    
    


# In[ ]:




