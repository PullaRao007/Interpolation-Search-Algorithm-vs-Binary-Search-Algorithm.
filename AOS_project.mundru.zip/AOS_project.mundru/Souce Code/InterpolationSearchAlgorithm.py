#!/usr/bin/env python
# coding: utf-8

# In[14]:


# program to implement interpolation search

# If x is present in arr[0..n-1], then
# returns index of it, else returns -1.
import time
import psutil

def interpolationSearch(arr, lo, hi, x):

	# Since array is sorted, an element present
	# in array must be in range defined by corner
	if (lo <= hi and x >= arr[lo] and x <= arr[hi]):

		# uniform distribution in mind.
		pos = lo + ((hi - lo) // (arr[hi] - arr[lo]) *
					(x - arr[lo]))
		if arr[pos] == x:
			return pos
		# If x is larger, x is in right subarray
		if arr[pos] < x:
			return interpolationSearch(arr, pos + 1,
									hi, x)
		# If x is smaller, x is in left subarray
		if arr[pos] > x:
			return interpolationSearch(arr, lo,
									pos - 1, x)
	return -1

def interpolationOutput():
	# Array of items in which search will be conducted
	arr = [10, 12, 13, 16, 18, 19, 20,
	21, 22, 23, 24, 33, 35, 42, 47, 29,
	50, 110,769, 678, 456, 455, 231, 567, 767, 900, 344, 57, 689, 456, 778, 998]
	n = len(arr)
	# Element to be searched
	x = 18
	start_time = time.time()
	index = interpolationSearch(arr, 0, n - 1, x)
	if index != -1:
		print("For Interpolation Search Algorithm:")
		print("\n")
		print("Element found at index", index)
		print("CPU Usage:", psutil.cpu_percent())
		print("Memory Usage:", psutil.virtual_memory().percent)
		print("Hard Drive Usage:", psutil.disk_usage('/').percent)
		print("RSS:", psutil.Process().memory_info().rss)
		print("VMS:", psutil.Process().memory_info().vms)
		print("Number of page faults :", psutil.Process().memory_info().num_page_faults)
		print("Program executed in about %s seconds" % (time.time() - start_time))
		print("\n")
	else:
		print("Element not found")
        
interpolationOutput()


# In[ ]:




