#!/usr/bin/env python
# coding: utf-8

# In[13]:


# Program for binary search.
# Returns index of x in arr if present, else -1
import time
import psutil

def binarySearch(arr, l, r, x):

	# Check base case
	if r >= l:
		mid = l + (r - l) // 2
		# If element is present at the middle itself
		if arr[mid] == x:
			return mid
		# If element is smaller than mid, then it
		# can only be present in left subarray
		elif arr[mid] > x:
			return binarySearch(arr, l, mid-1, x)
		# Else the element can only be present
		# in right subarray
		else:
			return binarySearch(arr, mid + 1, r, x)
	else:
		# Element is not present in the array
		return -1

def binarySearchOutput():
	# array of numbers
	arr = [2, 3, 4, 10, 40, 66, 89, 91, 98, 103,
			108, 111, 123, 156, 178, 234, 256, 276,
			343, 567, 678, 721, 746, 765, 801, 834]
	# consider the target number x
	x = 10
	start_time = time.time()
	# Function call
	result = binarySearch(arr, 0, len(arr)-1, x)
	if result != -1:
		print("For Binary Search Algorithm")
		print("\n")
		print("Element is present at index % d" % result)
		print("CPU Usage:", psutil.cpu_percent())
		print("Memory Usage:", psutil.virtual_memory().percent)
		print("Hard Drive Usage:", psutil.disk_usage('/').percent)
		print("RSS:", psutil.Process().memory_info().rss)
		print("VMS:", psutil.Process().memory_info().vms)
		print("Number of page faults:", psutil.Process().memory_info().num_page_faults)
		print("Program executed in about %s seconds" % (time.time() - start_time))
		print("\n")
	else:
		print("Element is not present in array")

binarySearchOutput()


# In[ ]:





# In[ ]:




